#include <stdio.h>
#include <stdbool.h>
#include <string.h>

#define MAX_DATA 10

typedef int element;
// ť
typedef struct queue {
	int front;
	int tail;
	node data[MAX_DATA];
}queue;
// Ʈ��
typedef struct node {
	element data;
	struct node *left;
	struct node *right;
	bool visited;
}node;

void init_queue(queue *base);
int is_empty(queue *base);
int is_full(queue *base);
void enqueue(queue *base, node *value);
node dequeue(queue *base);

void bfs(node *root);
void visit(node *root);

queue test2;

