#include "bfs.h"
/*
	BFS = Breadth First Search = �ʺ� �켱 Ž��

	�ַ� �ִ� ��θ� ã���شٴ� ������ �ִ� ���̸� �����Ҷ� ���� ���
	�غ� ť

	 
*/



void init_queue(queue *base) {
	base->front = base->tail= -1;
	memset(base->data, 0, sizeof(base->data));
}
int is_empty(queue *base) {
	if (base->front == base->tail) {
		return true;
	}
	else
		return false;
}
int is_full(queue *base) {
	if (base->tail == MAX_DATA-1) {
		return true;
	}
	else {
		return false;
	}
}
void enqueue(queue *base, node *value) {
	if (is_full(base)) {
		fprintf(stderr, "��á��");
		exit(1);
	}
	base->data[++(base->tail)] = *value;
	value->visited = true;
}
node dequeue(queue *base) {
	//int reu;
	if (is_empty(base)) {
		fprintf(stderr, "����");
		exit(1);
	}
	return base->data[++(base->front)];
}



// bfs ����
void bfs(node *root) {
	init_queue(&test2);
	enqueue(&test2, root);
	node now;
	while (!is_empty(&test2)) {
		now = dequeue(&test2);
		visit(&now);
	}
}
void visit(node *root) {
	if (root->left != NULL) {
		enqueue(&test2, root->left);
	}
	if (root->right != NULL) {
		enqueue(&test2, root->right);
	}
}

// ����
int main() {
	queue test;

	init_queue(&test);
	node n1 = { 4, NULL, NULL, false };
	node n2 = { 5, NULL, NULL, false };
	node n3 = { 2, &n1, &n2, false };
	node n4 = { 6, NULL, NULL, false };
	node n5 = { 7, NULL, NULL, false };
	node n6 = { 3, &n4, &n5, false };
	node root = { 1, &n3, &n6, false };
	
	bfs(&root);
	for (int i = 0; i < MAX_DATA; i++) {
		printf("%d ", test.data[i]);
	}
}